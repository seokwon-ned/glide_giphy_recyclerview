package com.example.gifsample

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.ListPreloader.PreloadModelProvider
import com.bumptech.glide.RequestBuilder
import com.bumptech.glide.integration.recyclerview.RecyclerViewPreloader
import com.bumptech.glide.util.ViewPreloadSizeProvider
import com.example.gifsample.giphy.Api
import com.example.gifsample.giphy.Api.GifResult
import com.example.gifsample.giphy.FullscreenActivity


/**
 * The primary activity in the Giphy sample that allows users to view trending animated GIFs from
 * Giphy's api.
 */
class MainActivity : Activity(), Api.Monitor {
    private var adapter: GifAdapter? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val giphyLogoView = findViewById<View>(R.id.giphy_logo_view) as ImageView

        Glide.with(this).load(R.raw.large_giphy_logo)
                .into(giphyLogoView)

        val gifList = findViewById<View>(R.id.gif_list) as RecyclerView

        val gridMargin = resources.getDimensionPixelOffset(R.dimen.grid_margin)
        val spanCount: Int = 3

        val layoutManager = GridLayoutManager(this, spanCount)
        gifList.layoutManager = layoutManager

        val gifItemRequest: RequestBuilder<Drawable> = Glide.with(this)
            .asDrawable()

        val preloadSizeProvider =
            ViewPreloadSizeProvider<GifResult>()

        adapter = GifAdapter(this, gifItemRequest, preloadSizeProvider)
        gifList.adapter = adapter

        val preloader: RecyclerViewPreloader<GifResult> =
            RecyclerViewPreloader(Glide.with(this), adapter as PreloadModelProvider<GifResult>, preloadSizeProvider, 4)
        gifList.addOnScrollListener(preloader)
    }

    override fun onStart() {
        super.onStart()
        Api.get().addMonitor(this)
        if (adapter!!.itemCount == 0) {
            Api.get().getTrending()
        }
    }

    override fun onStop() {
        super.onStop()
        Api.get().removeMonitor(this)
    }

    override fun onSearchComplete(result: Api.SearchResult) {
        adapter!!.setResults(result.data)
    }

    private class GifAdapter internal constructor(
        private val activity: Activity, private val requestBuilder: RequestBuilder<Drawable>,
        private val preloadSizeProvider: ViewPreloadSizeProvider<GifResult>
    ) : RecyclerView.Adapter<GifViewHolder>(), PreloadModelProvider<GifResult> {
        private var results =
            EMPTY_RESULTS

        fun setResults(results: Array<GifResult?>?) {
            if (results != null) {
                this.results = results
            } else {
                this.results = EMPTY_RESULTS
            }
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(
            parent: ViewGroup,
            viewType: Int
        ): GifViewHolder {
            val view: View =
                activity.layoutInflater.inflate(R.layout.gif_list_item, parent, false)
            return GifViewHolder(view)
        }

        override fun onBindViewHolder(
            holder: GifViewHolder,
            position: Int
        ) {
            val result = results[position]
            holder.gifView.setOnClickListener {
                onClickedGifView(result)
            }
            requestBuilder.load(result).into(holder.gifView)
            preloadSizeProvider.setView(holder.gifView)
        }

        private fun onClickedGifView(result: GifResult?) {

            if(result == null){
                return
            }

            val clipboard =
                    activity.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip =
                    ClipData.newPlainText("giphy_url", result.images.fixed_height.url)
            clipboard.setPrimaryClip(clip)
            val fullscreenIntent = FullscreenActivity.getIntent(activity, result)
            activity.startActivity(fullscreenIntent)
        }

        override fun getItemId(i: Int): Long {
            return 0
        }

        override fun getItemCount(): Int {
            return results.size
        }

        override fun getPreloadItems(position: Int): List<GifResult> {
            return listOf(results[position] as GifResult)
        }

        override fun getPreloadRequestBuilder(item: GifResult): RequestBuilder<Drawable> {
            return requestBuilder.load(item)
        }

        companion object {
            private val EMPTY_RESULTS = arrayOfNulls<GifResult>(0)
        }

    }

    private class GifViewHolder internal constructor(itemView: View) :
        RecyclerView.ViewHolder(itemView) {
        var gifView: ImageView

        init {
            gifView =
                itemView.findViewById<View>(R.id.gif_view) as ImageView
        }
    }
}
